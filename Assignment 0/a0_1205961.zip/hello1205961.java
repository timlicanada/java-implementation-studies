/*
 * HelloWorld.java
 * Name: Tim Li
 * Student Number: 1205961
 */

public class hello1205961 {
  public static void main(String[] args) {
    System.out.println("Hello, and welcome to CS2S03!");
  }
}