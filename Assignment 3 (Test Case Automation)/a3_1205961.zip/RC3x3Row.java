public class RC3x3Row{//this class represents a row record containing 3 long column values
	long c1, c2, c3;
	public void setC1(long c1){
		this.c1 = c1;
	}
	public void setC2(long c2){
		this.c2 = c2;
	}
	public void setC3(long c3){
		this.c3 = c3;
	}
	public long getC1(){
		return c1;
	}
	public long getC2(){
		return c2;
	}
	public long getC3(){
		return c3;
	}
}