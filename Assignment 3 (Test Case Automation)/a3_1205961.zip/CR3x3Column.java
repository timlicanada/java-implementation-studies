public class CR3x3Column { //this class represents a column record containing 3 row long values
	long r1, r2, r3;
	public void setR1(long r1){
		this.r1 = r1;
	}
	public void setR2(long r2){
		this.r2 = r2;
	}
	public void setR3(long r3){
		this.r3 = r3;
	}
	public long getR1(){
		return r1;
	}
	public long getR2(){
		return r2;
	}
	public long getR3(){
		return r3;
	}
}
