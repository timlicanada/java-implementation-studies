import java.io.PrintStream;
import java.util.ArrayList;

public class ArrayListStack implements StackInterface{
	private ArrayList al = new ArrayList();
	
	public ArrayListStack(){

	}
	
	public ArrayListStack(ArrayList al){
		this.al = al;
	}
	
	public boolean isempty(){
		return al.isEmpty();
	}
	
	public void push(final char a){
		this.al.add(a);
	}
	
	public void pop(){
		  if (al.size() == 0){
			throw new ArrayIndexOutOfBoundsException("Invalid index, can't pop empty stack");
		  }else{	
			  al.remove(al.size()-1);
		  }
	}
	
	public char top(){
		  if (al.size() == 0){
			  throw new ArrayIndexOutOfBoundsException("Invalid index, can't look for top in empty stack");
		  }else{		
			  return (char) al.get(al.size()-1);
		  }
	}

	public void show(PrintStream p) {
		String tempString = "";
		for (int i =0; i<=(al.size()-1);i++){
			tempString = tempString + al.get(i);
		}
		p.print(tempString);
	}

}
