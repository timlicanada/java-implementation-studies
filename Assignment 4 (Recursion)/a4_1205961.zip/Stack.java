import java.io.*;

public class Stack implements StackInterface{
  private List c;

	  public Stack() { 
		  this.c = null; 
	  }
	  public Stack(final List l) { 
		  this.c = l; 
	  }
	  public boolean isempty() { 
		  return c == null; 
	  }
	  public void push(final char a) { 
		  c = new List(a, c);

	  }
	  public void pop() { 
		  if (c==null){
			  throw new NullPointerException("Can't pop anything, empty stack");
		  }else{
			  c = c.getTail();

		  }
	  }
	  public char top() {
		  if (c == null){
			  throw new NullPointerException("Can't look for top in empty stack");
		  }else{
			  return c.getHead(); 
		  }
	  }
	  public void show(PrintStream p) {
		  String tempString = "";
		  List tempC = c;
		  while(tempC.getTail() != null){
			  tempString = tempString + tempC.getHead();
			  tempC = tempC.getTail();
		  }
		  tempString = tempString + tempC.getHead();
		  String reverse = new StringBuffer(tempString).reverse().toString();
		  p.print(reverse);
	  }
}