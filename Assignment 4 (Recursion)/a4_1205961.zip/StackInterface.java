import java.io.PrintStream;


public interface StackInterface {
	public char top();
	public void pop();
	public void push(char c);
	public boolean isempty();
	public void show(PrintStream p);
}
