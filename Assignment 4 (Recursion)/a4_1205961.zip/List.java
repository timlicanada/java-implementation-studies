public class List {
  private char hd;
  private List tl;
  List(final char a, final List ll) {
    this.hd = a;
    this.tl = ll; 
  }
  public char getHead(){
	  return this.hd;
  }
  public List getTail(){
	  return this.tl;
  }
}