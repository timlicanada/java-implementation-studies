import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.rules.ExpectedException;

public class Test {

	@org.junit.Test
	public void test() {

		// Beginning of Stack(part 1) test cases

		// First sequence: push 3 characters
		ByteArrayOutputStream bos1 = new ByteArrayOutputStream();
		PrintStream p1 = new PrintStream(bos1);
		Stack obj1 = new Stack();
		obj1.push('t');
		obj1.push('i');
		obj1.push('m');
		obj1.show(p1);
		assertEquals(bos1.toString(), "tim");

		// Second sequence: push 2 char, pop 1 char
		ByteArrayOutputStream bos2 = new ByteArrayOutputStream();
		PrintStream p2 = new PrintStream(bos2);
		Stack obj2 = new Stack();
		obj2.push('t');
		obj2.push('i');
		obj2.pop();
		obj2.show(p2);
		assertEquals(bos2.toString(), "t");

		// Third sequence: push 2 char, pop 2 char, check isempty
		Stack obj3 = new Stack();
		obj3.push('t');
		obj3.push('i');
		obj3.pop();
		obj3.pop();
		assertEquals(obj3.isempty(), true);

		// Fourth sequence: push 3 char pop 1 char, check isempty
		Stack obj4 = new Stack();
		obj4.push('t');
		obj4.push('i');
		obj4.push('m');
		obj4.pop();
		assertEquals(obj4.isempty(), false);

		// Fifth sequence: 15 operations - push 10 char, pop 5 char
		ByteArrayOutputStream bos5 = new ByteArrayOutputStream();
		PrintStream p5 = new PrintStream(bos5);
		Stack obj5 = new Stack();
		for (int i = 0; i <= 9; i++) {
			obj5.push('t');
		}
		for (int i = 0; i <= 4; i++) {
			obj5.pop();

		}
		obj5.show(p5);
		assertEquals(bos5.toString(), "ttttt");

		// Sixth sequence: 15 operations - push 14 char, check isempty
		ByteArrayOutputStream bos6 = new ByteArrayOutputStream();
		PrintStream p6 = new PrintStream(bos6);
		Stack obj6 = new Stack();
		for (int i = 0; i <= 13; i++) {
			obj6.push('t');
		}
		assertEquals(obj6.isempty(), false);

		// Seventh sequence: 15 operations- push 14 char, check top
		Stack obj7 = new Stack();
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('t');
		obj7.push('i');// top character
		assertEquals(obj7.top(), 'i');

		// Eighth sequence: calling top on empty stack
		Stack obj8 = new Stack();
		try {
			obj8.top();
			fail("Should throw NullPointerException, no top in empty stack");
		} catch (NullPointerException e) {
			assertEquals(e.getMessage(), "Can't look for top in empty stack");
		}

		// Ninth Sequence: pop on empty stack
		ByteArrayOutputStream bos9 = new ByteArrayOutputStream();
		PrintStream p9 = new PrintStream(bos9);
		Stack obj9 = new Stack();
		try {
			obj9.pop();
			fail("Should throw NullPointerException, nothing left in empty stack to pop");
		} catch (NullPointerException e) {
			assertEquals(e.getMessage(), "Can't pop anything, empty stack");
		}

		// Tenth Sequence: push on 3 chars, pop all 3 chars, attempt another pop
		ByteArrayOutputStream bos10 = new ByteArrayOutputStream();
		PrintStream p10 = new PrintStream(bos10);
		Stack obj10 = new Stack();
		obj10.push('t');
		obj10.push('i');
		obj10.push('m');
		obj10.pop();
		obj10.pop();
		obj10.pop();
		try {
			obj10.pop();
			fail("Should throw NullPointerException, nothing left in empty stack to pop");
		} catch (NullPointerException e) {
			assertEquals(e.getMessage(), "Can't pop anything, empty stack");
		}

		// End of Stack (part 1) test cases

		// Beginning of ArrayList Stack (part 2) test cases

		// First sequence: push 3 characters
		ByteArrayOutputStream bos1b = new ByteArrayOutputStream();
		PrintStream p1b = new PrintStream(bos1b);
		ArrayListStack obj1b = new ArrayListStack();
		obj1b.push('t');
		obj1b.push('i');
		obj1b.push('m');
		obj1b.show(p1b);
		assertEquals(bos1b.toString(), "tim");

		// Second sequence: push 2 char, pop 1 char
		ByteArrayOutputStream bos2b = new ByteArrayOutputStream();
		PrintStream p2b = new PrintStream(bos2b);
		ArrayListStack obj2b = new ArrayListStack();
		obj2b.push('t');
		obj2b.push('i');
		obj2b.pop();
		obj2b.show(p2b);
		assertEquals(bos2b.toString(), "t");

		// Third sequence: push 2 char, pop 2 char, check isempty
		ArrayListStack obj3b = new ArrayListStack();
		obj3b.push('t');
		obj3b.push('i');
		obj3b.pop();
		obj3b.pop();
		assertEquals(obj3b.isempty(), true);

		// Fourth sequence: push 3 char pop 1 char, check isempty
		ArrayListStack obj4b = new ArrayListStack();
		obj4b.push('t');
		obj4b.push('i');
		obj4b.push('m');
		obj4b.pop();
		assertEquals(obj4.isempty(), false);

		// Fifth sequence: 15 operations - push 10 char, pop 5 char
		ByteArrayOutputStream bos5b = new ByteArrayOutputStream();
		PrintStream p5b = new PrintStream(bos5b);
		ArrayListStack obj5b = new ArrayListStack();
		for (int i = 0; i <= 9; i++) {
			obj5b.push('t');
		}
		for (int i = 0; i <= 4; i++) {
			obj5b.pop();

		}
		obj5b.show(p5b);
		assertEquals(bos5b.toString(), "ttttt");

		// Sixth sequence: 15 operations - push 14 char, check isempty
		ByteArrayOutputStream bos6b = new ByteArrayOutputStream();
		PrintStream p6b = new PrintStream(bos6b);
		ArrayListStack obj6b = new ArrayListStack();
		for (int i = 0; i <= 13; i++) {
			obj6b.push('t');
		}
		assertEquals(obj6b.isempty(), false);

		// Seventh sequence: 15 operations- push 14 char, check top
		Stack obj7b = new Stack();
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('t');
		obj7b.push('i');// top character
		assertEquals(obj7b.top(), 'i');

		// Eighth sequence: calling top on empty stack
		ArrayListStack obj8b = new ArrayListStack();
		try {
			obj8b.top();
			fail("Should throw ArrayIndexOutOfBoundsException, no top in empty stack");
		} catch (ArrayIndexOutOfBoundsException e) {
			assertEquals(e.getMessage(), "Invalid index, can't look for top in empty stack");
		}

		// Ninth Sequence: pop on empty stack
		ByteArrayOutputStream bos9b = new ByteArrayOutputStream();
		PrintStream p9b = new PrintStream(bos9);
		ArrayListStack obj9b = new ArrayListStack();
		try {
			obj9b.pop();
			fail("Should throw ArrayIndexOutOfBoundsException, nothing left in empty stack to pop");
		} catch (ArrayIndexOutOfBoundsException e) {
			assertEquals(e.getMessage(), "Invalid index, can't pop empty stack");
		}
		
		// Tenth Sequence: push on 3 chars, pop all 3 chars, attempt another pop
		ByteArrayOutputStream bos10b = new ByteArrayOutputStream();
		PrintStream p10b = new PrintStream(bos10b);
		ArrayListStack obj10b = new ArrayListStack();
		obj10b.push('t');
		obj10b.push('i');
		obj10b.push('m');
		obj10b.pop();
		obj10b.pop();
		obj10b.pop();
		try {
			obj10b.pop();
			fail("Should throw ArrayIndexOutOfBoundsException, nothing left in empty stack to pop");
		} catch (ArrayIndexOutOfBoundsException e) {
			assertEquals(e.getMessage(), "Invalid index, can't pop empty stack");
		}
		
		
		//End of ArrayList Stack (part 2) test cases
	}

}
